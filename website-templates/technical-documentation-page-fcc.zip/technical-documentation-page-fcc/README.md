# Technical Documentation Page | FCC  

A Pen created on CodePen.

Original URL: [https://codepen.io/sklaerenn/pen/WOaKqM](https://codepen.io/sklaerenn/pen/WOaKqM).

freeCodeCamp project 4:  
Build a Technical Documentation Page
(using Bootstrap4, SASS, jQuery)