# blog-sidebar-layout-7a-travel-blog

A Pen created on CodePen.

Original URL: [https://codepen.io/mdo90/pen/OJqKaEM](https://codepen.io/mdo90/pen/OJqKaEM).

