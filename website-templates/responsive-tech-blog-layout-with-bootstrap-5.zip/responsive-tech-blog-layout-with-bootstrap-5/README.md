# Responsive Tech Blog Layout with Bootstrap 5

A Pen created on CodePen.

Original URL: [https://codepen.io/nimra-iqbal/pen/ZYbmvRz](https://codepen.io/nimra-iqbal/pen/ZYbmvRz).

This project is a modern and responsive blog template built using Bootstrap 5, designed for tech or news websites. Features include:

Responsive header and navigation with subscribe and search options

Hero section for highlighting featured articles

Feature cards to showcase trending posts with images and excerpts

Main blog content area with multiple articles, headings, and meta information

Sticky sidebar for About, Archives, and social links

Clean footer with copyright and back-to-top navigation

Fully mobile-first design, optimized for desktop, tablet, and mobile screens

Perfect for demonstrating front-end development skills, blog layouts, and Bootstrap 5 proficiency.