// find each start and end accordion elements and make a container accordion
$('hr.accordion-start').each(function() {
  $(this).nextUntil('hr.accordion-end').wrapAll('<div class="accordion"></div>');
});

// wrap the content of each section in a div
$('.accordion h3').each(function() {
  $(this).nextUntil('.accordion h3').wrapAll('<div></div>');
});

// activate the accordions
$('.accordion').accordion({
  active: false,
  collapsible: true,
  heightStyle: 'content'
});

// remove the hr elements that are now unnecessary
$('hr.accordion-start').remove();
$('hr.accordion-end').remove();

// add the arrows for fanciness
$('.accordion h3').prepend('<span class="arrow">&#x25B6;</span>');