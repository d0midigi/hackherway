# jQuery UI Accordions without the Markup

A Pen created on CodePen.

Original URL: [https://codepen.io/typogrammer/pen/ZGEjEL](https://codepen.io/typogrammer/pen/ZGEjEL).

I wanted a simple way for users in our CMS to make accordions without needing to worry about the markup. They should only need to make two marks: where each accordion starts and ends. It should support multiple accordions on a single page.

[Update 6/18/15] Cleaned up the look a bit to make it suck less.