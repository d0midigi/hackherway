# Accessible Accordion & Toggles v2

A Pen created on CodePen.

Original URL: [https://codepen.io/Webactually/pen/wvNmMq](https://codepen.io/Webactually/pen/wvNmMq).

A lighter code without plugins, ready to use. Work with classes only and a minimal markup.