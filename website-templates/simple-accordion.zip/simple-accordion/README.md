# Simple Accordion

A Pen created on CodePen.

Original URL: [https://codepen.io/zeinab92/pen/PwZXgd](https://codepen.io/zeinab92/pen/PwZXgd).

