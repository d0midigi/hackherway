# Two-column blog / fixed sidebar

A Pen created on CodePen.

Original URL: [https://codepen.io/justinav/pen/jbLxje](https://codepen.io/justinav/pen/jbLxje).

