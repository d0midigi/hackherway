# Slack Theming with CSS Custom Properties

A Pen created on CodePen.

Original URL: [https://codepen.io/ramenhog/pen/yXYNzz](https://codepen.io/ramenhog/pen/yXYNzz).

Recreated the native theming functionality in Slack with CSS custom properties and...a bit of magic ;)

Blog post here: http://ramenhog.com/blog/2017/06/07/theming-with-css-custom-properties

---

Functionality:

1. Select your theme from one of the preset themes
2. Change the color of individual theme properties to generate your own custom theme
3. Copy and paste the generated theme into the actual Slack app or vice versa to apply your custom theme 
4. Selected theme is stored in LocalStorage and applied upon reload