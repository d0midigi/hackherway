# sidebar blog

A Pen created on CodePen.

Original URL: [https://codepen.io/willmansueto/pen/vYegreK](https://codepen.io/willmansueto/pen/vYegreK).

