# Responsive Tabs (v1.1)

A Pen created on CodePen.

Original URL: [https://codepen.io/aaronpinero/pen/dyJWQo](https://codepen.io/aaronpinero/pen/dyJWQo).

Pattern that is an collapsable sections at small screen sizes and horizontal tabs at larger screen sizes