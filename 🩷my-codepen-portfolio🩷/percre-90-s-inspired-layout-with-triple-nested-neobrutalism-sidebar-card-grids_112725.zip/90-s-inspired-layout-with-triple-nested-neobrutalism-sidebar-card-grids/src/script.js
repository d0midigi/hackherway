function toggleMenu(id, element) {
    // Get the submenu
    var submenu = document.getElementById(id);
    
    // Get the arrow
    var arrow = element.querySelector('.arrow');
    
    // Toggle the submenu
    if (submenu.classList.contains('show')) {
        submenu.classList.remove('show');
        arrow.textContent = '▶';
    } else {
        submenu.classList.add('show');
        arrow.textContent = '▼';
    }
}
