# '90's Inspired Layout with Triple-Nested Neobrutalism Sidebar & Card Grids

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/ZYWoWKx](https://codepen.io/Yvonne-Angelica/pen/ZYWoWKx).

Jumped on the Neobrutalism wave.