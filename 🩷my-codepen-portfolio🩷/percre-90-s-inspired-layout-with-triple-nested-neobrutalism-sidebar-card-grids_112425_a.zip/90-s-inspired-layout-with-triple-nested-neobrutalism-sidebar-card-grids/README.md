# '90's Inspired Layout with Triple-Nested Neobrutalism Sidebar & Card Grids

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/ogxpQGp](https://codepen.io/Yvonne-Angelica/pen/ogxpQGp).

Jumped on the Neobrutalism wave.