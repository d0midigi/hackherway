# Responsive Tailwind Navbar w/Light & Dark Toggle

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/WbwWvKZ](https://codepen.io/Yvonne-Angelica/pen/WbwWvKZ).

This navbar has everything a navbar needs, including a logo, navigation links, a dropdown menu, a search bar, and even a cool light/dark mode switch.

