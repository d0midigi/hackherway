# Admin Mockup example 1

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/raxdENp](https://codepen.io/Yvonne-Angelica/pen/raxdENp).

// Admin UI Template example
// Its a very simple mockup for a admin dashboard 
// Can be used to whatever. But mainly it has been used to maintain redis
// and for own customized database for postgresql or just 
// It use basically two main external resources (yeah and jquery but 
// didn't count that in here as so important)
// fancytree , split and jquery. The basic layout of the admin dashboard
// is based on css grids and flex. But its very very very simple 
// css grid layout. People often think it need advance framework
// to make it being setup, but it turns out to be very simple indeed
// but don't be fooled. The connection however between the UI and
// (front) back-end might to update etc might better 
// need react, angularjs, vue, backend.js 
// or just nice old jquery. The choice is yours of course in benefit for your
// favorized framework to work with. But for the design/layout
// you not even need bootstrap or another heavy css-lib or even
// above javascript. It can simpel been done with css grid and flex 
// However its not responsive! didn't found a nice solution and
// the purpose is not here to demonstrate and get it ready for being used
// for a cell phone, only for web browsers and ipads. 
// The goal here is to make it look little bit like the google material design
