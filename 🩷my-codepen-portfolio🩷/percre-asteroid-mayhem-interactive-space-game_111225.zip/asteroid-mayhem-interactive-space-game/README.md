# Asteroid Mayhem-Interactive Space Game

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/zxqvOaR](https://codepen.io/Yvonne-Angelica/pen/zxqvOaR).

A fast-paced interactive space shooter where you dodge and destroy asteroids. Built with HTML, CSS, and JavaScript for smooth animations and responsive gameplay.