# Form Wave Animation

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/ByKegXr](https://codepen.io/Yvonne-Angelica/pen/ByKegXr).

This project features an interactive form where HTML, CSS, and vanilla JS combine to create a "wave" animation effect. Initially inside the input fields, the labels dynamically transition the test into a staggered wave pattern using JS class toggles and smooth CSS transitions, providing a modern and engaging user experience for form input.