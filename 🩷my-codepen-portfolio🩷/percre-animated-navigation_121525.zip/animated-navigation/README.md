# Animated Navigation

A Pen created on CodePen.

Original URL: [https://codepen.io/Yvonne-Angelica/pen/vEGqBBz](https://codepen.io/Yvonne-Angelica/pen/vEGqBBz).

This project features a sleek, expanding navigation bar that uses toggle button, the menu dynamically transforms from compact icon into a full-width horizontal list. The animation utilizes CSS transitions to smoothly expand the container while rotating the menu items 360 degrees and fading them into view, creating a polished, high-energy user interface. And, I love this color combination, so yeah, there's that...    o(^_^)o